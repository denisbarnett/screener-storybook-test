## A simple React app configured for React Storybook.

This is a "Create React App" based React app configured for React Storybook.

### Setting Up

```sh
npm i
```

### Run Storybook

```sh
npm run storybook
```
